<?php
include "config.php";

//check if the user is registered on click submit
if(isset($_POST['login_btn'])){
    //declare the login inputs for easy check
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $password = filter_var($_POST['password'], FILTER_SANITIZE_STRING);

    $select = mysqli_query($conn, "SELECT * FROM users WHERE email='$email' AND password='$password'") or die("select query error");
    //check if user exist
    if(mysqli_num_rows($select) > 0){
        $row = mysqli_fetch_assoc($select);
        //declare and set session variables
        $_SESSION['name'] = $row['user_name'];
        $_SESSION['email'] = $row['email'];
        //redirect the user to the home page
        header("Location: index.php");
        
    }else{
        echo "Incorrect email or password";
    }

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Devsy Code Labs</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body style="background-color:#eee;">
    <section class="register">
        <div class="form-container">
            <center><h1>Welcome back! Login here</h1></center>
            <form action="" method="post">
               <span>Email</span><br>
                <input type="email" name="email" class="input" placeholder="Enter your Email"><br>
                <span>Password</span><br>
                <input type="password" name="password" class="input" placeholder="Enter your password"><br>
                <input type="submit" class="btn" value="Login" name="login_btn"><br>
                <center><a href="register.php">Dont have an account, register</a></center><br>
                <a href="index.php">Back to home</a>
            </form>
        </div>
    </section>
    
</body>
</html>