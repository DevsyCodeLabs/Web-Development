<?php
//start the session
session_start();
//destroy the sessions
session_destroy();
//redirect to login
header("Location: login.php");
