<?php
include "config.php";

//check if the session is s
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Devsy Code Labs</title>
    <!-- link the css -->
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <nav class="navbar">
        <div class="navdiv">
            <div class="logo"><a href="#">Devsy Code Labs</a></div>
            <ul>
                <li><a href="#">Home</a></li>
                <li><a href="#">About</a></li>
                <li><a href="#">Services</a></li>
                <li><a href="#">Contact</a></li>
                <?php
                //if isset echo user details on login
                if(isset($_SESSION['email'])){
                    echo '
                    <li><a href="#">Welcome back, '.$_SESSION["name"].'</a></li>
                    <button class="outline"><a href="logout.php">Logout</a></button>
                ';
                }else{echo '
                <button class="outline"><a href="login.php">Sign In</a></button>
                <button><a href="register.php">Sign Up</a></button>
                ';}
                ?>
            </ul>
        </div>
    </nav>
    <section class="content">
        <div class="float_left">
        <h1>Join the World's best Coding Channel</h1>
        <p>Welcome all as we develop a simple html, php mysqli project</p>
        <button><a href="register.php">Join Us</a></button>
        </div>
        <div class="float_right">
            <img src="images/home.gif" alt="">
        </div>
    </section>
</body>
</html>