<?php
//include database connection
include "config.php";
//handle posting data to the database using the post method
if(isset($_POST['register_btn'])){
    //declare the variables for the inputs to handle data collection
    $username = $_POST['user_name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $repassword = $_POST['repassword'];

    //check if the passwors and the confirm password match
    if($password != $repassword){
        echo "Password do not match";
    }
    else{
        //insert the data into the database
        $insert = mysqli_query($conn, "INSERT INTO users (user_name,email,password) VALUES ('$username','$email','$password')") or die("error inserting to the database");
        echo"Welcome $username to devsy code labs";
        //set session variables
        $_SESSION['name'] = $username;
        $_SESSION['email'] = $email;

        header("Location: index.php");
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Devsy Code Labs</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body style="background-color:#eee;">
    <section class="register">
        <div class="form-container">
            <center><h1>Welcome! Register here</h1></center>
            <form action="" method="post">
                <span>Username</span><br>
                <input type="text" class="input" name="user_name" placeholder="Enter your Username"><br>
                <span>Email</span><br>
                <input type="email" name="email" class="input" placeholder="Enter your Email"><br>
                <span>Password</span><br>
                <input type="password" name="password" class="input" placeholder="Enter your password"><br>
                <span>Confirm Password</span><br>
                <input type="password" name="repassword" class="input"><br>
                <input type="submit" class="btn" value="Register" name="register_btn"><br>
                <a href="login.php">Already have an account login</a><br>
                <a href="index.php">Back to home</a>
            </form>
        </div>
    </section>
    
</body>
</html>