<?php
//first start the session
session_start();
//connect to database
$conn = mysqli_connect('localhost','root','','devsy_code_labs') or die("error connecting to database");
?>